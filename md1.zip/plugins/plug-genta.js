let handler = async (m, { command, text }) => m.reply(`*-----------------------*
WARNING !! *USE GENTA HAX ON ALT ACCOUNT ONLY !!*
indo : *Gunakan Genta Hax diAkun kecil !!*
*------------------------*
Genta Hax 
_Support Android/Pc_

GENTA HAX v4.34 Patch 1.0
New:
- Remake UI on Misc & GTPS Tab
- leave world when mods join
- last try fix crash ( still crash? definitely device issue 🙂 )
- More ESP color setting
- Unlock limiter ( don't use on RGT! )
https://www.mediafire.com/file/uiz9o5l3frkwrds/GENTA+HAX+v4.34+Patch+1.0.apk/file

*_FYI ( FOR YOUR INFORMATION)_*

-Jika Muncul Disuruh Masukan Unsername Dan Password Kalian Tinggal Pencet Login aja !!`)

handler.help = ['gentahax']
handler.tags = ['tools']
handler.command = /^(gentahax)$/i

export default handler